"use server";

import { revalidatePath } from "next/cache";

import { createClient } from "@/lib/supabase/server";

async function requireAdminUser() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return null;
  }

  const { data: profile } =
    await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single();

  if (!profile || profile.role !== "admin") {
    return null;
  }

  return {
    user,
    profile,
  };
}

export async function approveDeposit(
  depositId: string
) {
  const admin =
    await requireAdminUser();

  if (!admin) {
    return {
      error: "Unauthorized",
    };
  }

  const supabase = await createClient();

  const { data: deposit } =
    await supabase
      .from("deposits")
      .select("*")
      .eq("id", depositId)
      .single();

  if (!deposit) {
    return {
      error: "Deposit not found",
    };
  }

  if (deposit.status === "approved") {
    return {
      error: "Already approved",
    };
  }

  const { error: depositError } =
    await supabase
      .from("deposits")
      .update({
        status: "approved",
        approved_by: admin.user.id,
      })
      .eq("id", depositId);

  if (depositError) {
    return {
      error: depositError.message,
    };
  }

  const { data: wallet } =
    await supabase
      .from("wallets")
      .select("*")
      .eq("user_id", deposit.user_id)
      .single();

  if (!wallet) {
    return {
      error: "Wallet not found",
    };
  }

  const newBalance =
    Number(
      wallet.available_balance
    ) + Number(deposit.amount);

  const { error: walletError } =
    await supabase
      .from("wallets")
      .update({
        available_balance:
          newBalance,
      })
      .eq("id", wallet.id);

  if (walletError) {
    return {
      error: walletError.message,
    };
  }

  revalidatePath("/admin/deposits");

  return {
    success: true,
  };
}

export async function rejectDeposit(
  depositId: string
) {
  const admin =
    await requireAdminUser();

  if (!admin) {
    return {
      error: "Unauthorized",
    };
  }

  const supabase = await createClient();

  const { error } = await supabase
    .from("deposits")
    .update({
      status: "rejected",
      approved_by: admin.user.id,
    })
    .eq("id", depositId);

  if (error) {
    return {
      error: error.message,
    };
  }

  revalidatePath("/admin/deposits");

  return {
    success: true,
  };
}