import { getCurrentProfile } from "@/services/profile-service";
import { getCurrentWallet } from "@/services/wallet-service";

export default async function MemberDashboardPage() {
  const profile = await getCurrentProfile();

  const wallet = await getCurrentWallet();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">
          Welcome back
        </h1>

        <p className="text-muted-foreground">
          {profile?.email}
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-xl border p-6">
          <h2 className="text-sm text-muted-foreground">
            Main Balance
          </h2>

          <p className="mt-2 text-3xl font-bold">
           ${wallet?.available_balance ?? 0}
          </p>
        </div>

        <div className="rounded-xl border p-6">
  <h2 className="text-sm text-muted-foreground">
    Locked Balance
  </h2>

  <p className="mt-2 text-3xl font-bold">
    ${wallet?.locked_balance ?? 0}
  </p>
</div>

        <div className="rounded-xl border p-6">
          <h2 className="text-sm text-muted-foreground">
            Profit Balance
          </h2>

          <p className="mt-2 text-3xl font-bold">
            ${wallet?.profit_balance ?? 0}
          </p>
        </div>

        <div className="rounded-xl border p-6">
          <h2 className="text-sm text-muted-foreground">
            Referral Balance
          </h2>

          <p className="mt-2 text-3xl font-bold">
            ${wallet?.referral_balance ?? 0}
          </p>
        </div>
      </div>
    </div>
  );
}