import Link from "next/link";

export function Sidebar() {
  return (
    <aside className="w-64 border-r bg-background">
      <div className="border-b p-6">
        <h2 className="text-xl font-bold">
          TradePoolNetwork
        </h2>
      </div>

      <nav className="space-y-2 p-4">
        <Link
          href="/member/dashboard"
          className="block rounded-md px-4 py-2 hover:bg-muted"
        >
          Dashboard
        </Link>

        <Link
          href="/member/wallet"
          className="block rounded-md px-4 py-2 hover:bg-muted"
        >
          Wallet
        </Link>

        <Link
          href="/member/deposits"
          className="block rounded-md px-4 py-2 hover:bg-muted"
        >
          Deposits
        </Link>

        <Link
          href="/member/withdrawals"
          className="block rounded-md px-4 py-2 hover:bg-muted"
        >
          Withdrawals
        </Link>
      </nav>
    </aside>
  );
}